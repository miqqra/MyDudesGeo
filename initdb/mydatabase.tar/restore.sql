--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.7 (Debian 15.7-1.pgdg110+1)
-- Dumped by pg_dump version 15.7 (Debian 15.7-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE postgres SET search_path TO '$user', 'public', 'topology', 'tiger';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO postgres;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO postgres;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO postgres;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO postgres;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO postgres;

--
-- Name: geo_cities_to_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_cities_to_location (
    id bigint NOT NULL,
    city text NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL
);


ALTER TABLE public.geo_cities_to_location OWNER TO postgres;

--
-- Name: COLUMN geo_cities_to_location.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_cities_to_location.id IS 'Id записи';


--
-- Name: COLUMN geo_cities_to_location.city; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_cities_to_location.city IS 'Город';


--
-- Name: COLUMN geo_cities_to_location.latitude; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_cities_to_location.latitude IS 'Широта';


--
-- Name: COLUMN geo_cities_to_location.longitude; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_cities_to_location.longitude IS 'Долгота';


--
-- Name: geo_cities_to_location_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_cities_to_location ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_cities_to_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_close_friends; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_close_friends (
    id bigint NOT NULL,
    person text NOT NULL,
    friend text NOT NULL
);


ALTER TABLE public.geo_close_friends OWNER TO postgres;

--
-- Name: COLUMN geo_close_friends.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_close_friends.id IS 'Id';


--
-- Name: COLUMN geo_close_friends.person; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_close_friends.person IS 'Id пользователя';


--
-- Name: COLUMN geo_close_friends.friend; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_close_friends.friend IS 'Id близкого друга';


--
-- Name: geo_close_friends_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_close_friends ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_close_friends_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_friend_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_friend_requests (
    id bigint NOT NULL,
    request_from text NOT NULL,
    request_to text NOT NULL,
    status text NOT NULL
);


ALTER TABLE public.geo_friend_requests OWNER TO postgres;

--
-- Name: COLUMN geo_friend_requests.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_friend_requests.id IS 'Id запроса';


--
-- Name: COLUMN geo_friend_requests.request_from; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_friend_requests.request_from IS 'От кого поступил запрос на дружбу';


--
-- Name: COLUMN geo_friend_requests.request_to; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_friend_requests.request_to IS 'Кому поступил запрос на дружбу';


--
-- Name: COLUMN geo_friend_requests.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_friend_requests.status IS 'Статус заявки';


--
-- Name: geo_friend_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_friend_requests ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_friend_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_friends; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_friends (
    id bigint NOT NULL,
    person text NOT NULL,
    friend text NOT NULL
);


ALTER TABLE public.geo_friends OWNER TO postgres;

--
-- Name: COLUMN geo_friends.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_friends.id IS 'Id';


--
-- Name: COLUMN geo_friends.person; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_friends.person IS 'Id пользователя';


--
-- Name: COLUMN geo_friends.friend; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_friends.friend IS 'Id друга';


--
-- Name: geo_friends_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_friends ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_friends_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_hobbies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_hobbies (
    id bigint NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.geo_hobbies OWNER TO postgres;

--
-- Name: COLUMN geo_hobbies.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_hobbies.id IS 'Id записи';


--
-- Name: COLUMN geo_hobbies.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_hobbies.name IS 'Название хобби';


--
-- Name: geo_hobbies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_hobbies ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_hobbies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_parties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_parties (
    id bigint NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    category text,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    creator text NOT NULL,
    participants jsonb,
    limits integer NOT NULL,
    visibility text NOT NULL,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone,
    link_dobro text,
    chat_id_telegram bigint,
    photo oid
);


ALTER TABLE public.geo_parties OWNER TO postgres;

--
-- Name: COLUMN geo_parties.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.id IS 'Id мероприятия';


--
-- Name: COLUMN geo_parties.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.name IS 'Название мероприятия';


--
-- Name: COLUMN geo_parties.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.description IS 'Описание мероприятия';


--
-- Name: COLUMN geo_parties.category; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.category IS 'Тип мероприятия';


--
-- Name: COLUMN geo_parties.latitude; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.latitude IS 'Широта';


--
-- Name: COLUMN geo_parties.longitude; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.longitude IS 'Долгота';


--
-- Name: COLUMN geo_parties.creator; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.creator IS 'Создатель мероприятия';


--
-- Name: COLUMN geo_parties.participants; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.participants IS 'Пользователи, которые записались на мероприятие';


--
-- Name: COLUMN geo_parties.limits; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.limits IS 'Ограничение по людям';


--
-- Name: COLUMN geo_parties.visibility; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.visibility IS 'Пользователи, которым можно видеть данное мероприятие';


--
-- Name: COLUMN geo_parties.start_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.start_time IS 'Время начала мероприятия';


--
-- Name: COLUMN geo_parties.end_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.end_time IS 'Время конца мероприятия';


--
-- Name: COLUMN geo_parties.link_dobro; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.link_dobro IS 'Ссылка на мероприятие в dobro.ru, если мероприятие было мигрировано';


--
-- Name: COLUMN geo_parties.chat_id_telegram; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.chat_id_telegram IS 'Id чата в Telegram';


--
-- Name: COLUMN geo_parties.photo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties.photo IS 'Фото мероприятия';


--
-- Name: geo_parties_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_parties_category (
    id bigint NOT NULL,
    category text NOT NULL
);


ALTER TABLE public.geo_parties_category OWNER TO postgres;

--
-- Name: COLUMN geo_parties_category.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties_category.id IS 'Id категории мероприятия';


--
-- Name: COLUMN geo_parties_category.category; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_parties_category.category IS 'Тип мероприятия';


--
-- Name: geo_parties_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_parties_category ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_parties_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_parties_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_parties ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_parties_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_party_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_party_roles (
    id bigint NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    party_id bigint NOT NULL
);


ALTER TABLE public.geo_party_roles OWNER TO postgres;

--
-- Name: COLUMN geo_party_roles.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_party_roles.id IS 'Id роли';


--
-- Name: COLUMN geo_party_roles.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_party_roles.name IS 'Название роли';


--
-- Name: COLUMN geo_party_roles.description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_party_roles.description IS 'Описание роли';


--
-- Name: COLUMN geo_party_roles.party_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_party_roles.party_id IS 'Id мероприятия';


--
-- Name: geo_party_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_party_roles ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_party_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_party_roles_party_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_party_roles ALTER COLUMN party_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_party_roles_party_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_party_roles_to_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_party_roles_to_users (
    id bigint NOT NULL,
    role_id bigint NOT NULL,
    username text NOT NULL
);


ALTER TABLE public.geo_party_roles_to_users OWNER TO postgres;

--
-- Name: COLUMN geo_party_roles_to_users.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_party_roles_to_users.id IS 'Id записи';


--
-- Name: COLUMN geo_party_roles_to_users.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_party_roles_to_users.role_id IS 'Id роли мероприятия';


--
-- Name: COLUMN geo_party_roles_to_users.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_party_roles_to_users.username IS 'Логин пользователя';


--
-- Name: geo_party_roles_to_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_party_roles_to_users ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_party_roles_to_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_party_roles_to_users_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_party_roles_to_users ALTER COLUMN role_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_party_roles_to_users_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_roles (
    id bigint NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.geo_roles OWNER TO postgres;

--
-- Name: COLUMN geo_roles.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_roles.id IS 'Id записи';


--
-- Name: COLUMN geo_roles.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_roles.name IS 'Название роли: удовлетворяет формату ROLE_*';


--
-- Name: geo_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_roles ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_users (
    id bigint NOT NULL,
    nickname text NOT NULL,
    firstname text NOT NULL,
    lastname text NOT NULL,
    birthdate date,
    sex text,
    info text,
    photo oid,
    freeze_location boolean DEFAULT false NOT NULL,
    tg_nickname text,
    tg_chat_id bigint
);


ALTER TABLE public.geo_users OWNER TO postgres;

--
-- Name: COLUMN geo_users.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users.id IS 'Id записи';


--
-- Name: COLUMN geo_users.nickname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users.nickname IS 'Ник пользователя';


--
-- Name: COLUMN geo_users.firstname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users.firstname IS 'Имя пользователя';


--
-- Name: COLUMN geo_users.lastname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users.lastname IS 'Фамилия пользователя';


--
-- Name: COLUMN geo_users.birthdate; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users.birthdate IS 'Дата рождения пользователя';


--
-- Name: COLUMN geo_users.sex; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users.sex IS 'Пол пользователя';


--
-- Name: COLUMN geo_users.info; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users.info IS 'О себе';


--
-- Name: COLUMN geo_users.photo; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users.photo IS 'Фото пользователя';


--
-- Name: COLUMN geo_users.freeze_location; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users.freeze_location IS 'Флаг заморозки локации пользователя';


--
-- Name: COLUMN geo_users.tg_nickname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users.tg_nickname IS 'Ник в Telegram';


--
-- Name: COLUMN geo_users.tg_chat_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users.tg_chat_id IS 'Id чата c пользователем в Telegram';


--
-- Name: geo_users_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_users_credentials (
    id bigint NOT NULL,
    username text NOT NULL,
    password text NOT NULL
);


ALTER TABLE public.geo_users_credentials OWNER TO postgres;

--
-- Name: COLUMN geo_users_credentials.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_credentials.id IS 'Id записи';


--
-- Name: COLUMN geo_users_credentials.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_credentials.username IS 'Логин пользователя';


--
-- Name: COLUMN geo_users_credentials.password; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_credentials.password IS 'Пароль пользователя';


--
-- Name: geo_users_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_users_credentials ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_users_credentials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_users ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_users_location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_users_location (
    id bigint NOT NULL,
    nickname text NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    "time" timestamp with time zone NOT NULL
);


ALTER TABLE public.geo_users_location OWNER TO postgres;

--
-- Name: COLUMN geo_users_location.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_location.id IS 'Id мероприятия';


--
-- Name: COLUMN geo_users_location.nickname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_location.nickname IS 'Ник пользователя';


--
-- Name: COLUMN geo_users_location.latitude; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_location.latitude IS 'Широта';


--
-- Name: COLUMN geo_users_location.longitude; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_location.longitude IS 'Долгота';


--
-- Name: COLUMN geo_users_location."time"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_location."time" IS 'Время считывания позиции';


--
-- Name: geo_users_location_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_users_location ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_users_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_users_to_hobbies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_users_to_hobbies (
    id bigint NOT NULL,
    hobby_name text NOT NULL,
    username text NOT NULL
);


ALTER TABLE public.geo_users_to_hobbies OWNER TO postgres;

--
-- Name: COLUMN geo_users_to_hobbies.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_to_hobbies.id IS 'Id записи';


--
-- Name: COLUMN geo_users_to_hobbies.hobby_name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_to_hobbies.hobby_name IS 'Id роли мероприятия';


--
-- Name: COLUMN geo_users_to_hobbies.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_to_hobbies.username IS 'Логин пользователя';


--
-- Name: geo_users_to_hobbies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_users_to_hobbies ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_users_to_hobbies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_users_to_parties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_users_to_parties (
    id bigint NOT NULL,
    party_id bigint NOT NULL,
    username text NOT NULL
);


ALTER TABLE public.geo_users_to_parties OWNER TO postgres;

--
-- Name: COLUMN geo_users_to_parties.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_to_parties.id IS 'Id записи';


--
-- Name: COLUMN geo_users_to_parties.party_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_to_parties.party_id IS 'Id мероприятия';


--
-- Name: COLUMN geo_users_to_parties.username; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_to_parties.username IS 'Логин пользователя - участника мероприятия';


--
-- Name: geo_users_to_parties_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_users_to_parties ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_users_to_parties_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_users_to_parties_party_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_users_to_parties ALTER COLUMN party_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_users_to_parties_party_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_users_to_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.geo_users_to_roles (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    role_id bigint NOT NULL
);


ALTER TABLE public.geo_users_to_roles OWNER TO postgres;

--
-- Name: COLUMN geo_users_to_roles.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_to_roles.id IS 'Id записи';


--
-- Name: COLUMN geo_users_to_roles.user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_to_roles.user_id IS 'Id пользователя';


--
-- Name: COLUMN geo_users_to_roles.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.geo_users_to_roles.role_id IS 'Id роли';


--
-- Name: geo_users_to_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_users_to_roles ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_users_to_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_users_to_roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_users_to_roles ALTER COLUMN role_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_users_to_roles_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: geo_users_to_roles_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.geo_users_to_roles ALTER COLUMN user_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.geo_users_to_roles_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
\.
COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM '$$PATH$$/4803.dat';

--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
\.
COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM '$$PATH$$/4804.dat';

--
-- Data for Name: geo_cities_to_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_cities_to_location (id, city, latitude, longitude) FROM stdin;
\.
COPY public.geo_cities_to_location (id, city, latitude, longitude) FROM '$$PATH$$/4841.dat';

--
-- Data for Name: geo_close_friends; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_close_friends (id, person, friend) FROM stdin;
\.
COPY public.geo_close_friends (id, person, friend) FROM '$$PATH$$/4820.dat';

--
-- Data for Name: geo_friend_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_friend_requests (id, request_from, request_to, status) FROM stdin;
\.
COPY public.geo_friend_requests (id, request_from, request_to, status) FROM '$$PATH$$/4822.dat';

--
-- Data for Name: geo_friends; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_friends (id, person, friend) FROM stdin;
\.
COPY public.geo_friends (id, person, friend) FROM '$$PATH$$/4818.dat';

--
-- Data for Name: geo_hobbies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_hobbies (id, name) FROM stdin;
\.
COPY public.geo_hobbies (id, name) FROM '$$PATH$$/4816.dat';

--
-- Data for Name: geo_parties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_parties (id, name, description, category, latitude, longitude, creator, participants, limits, visibility, start_time, end_time, link_dobro, chat_id_telegram, photo) FROM stdin;
\.
COPY public.geo_parties (id, name, description, category, latitude, longitude, creator, participants, limits, visibility, start_time, end_time, link_dobro, chat_id_telegram, photo) FROM '$$PATH$$/4814.dat';

--
-- Data for Name: geo_parties_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_parties_category (id, category) FROM stdin;
\.
COPY public.geo_parties_category (id, category) FROM '$$PATH$$/4812.dat';

--
-- Data for Name: geo_party_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_party_roles (id, name, description, party_id) FROM stdin;
\.
COPY public.geo_party_roles (id, name, description, party_id) FROM '$$PATH$$/4831.dat';

--
-- Data for Name: geo_party_roles_to_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_party_roles_to_users (id, role_id, username) FROM stdin;
\.
COPY public.geo_party_roles_to_users (id, role_id, username) FROM '$$PATH$$/4834.dat';

--
-- Data for Name: geo_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_roles (id, name) FROM stdin;
\.
COPY public.geo_roles (id, name) FROM '$$PATH$$/4824.dat';

--
-- Data for Name: geo_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_users (id, nickname, firstname, lastname, birthdate, sex, info, photo, freeze_location, tg_nickname, tg_chat_id) FROM stdin;
\.
COPY public.geo_users (id, nickname, firstname, lastname, birthdate, sex, info, photo, freeze_location, tg_nickname, tg_chat_id) FROM '$$PATH$$/4808.dat';

--
-- Data for Name: geo_users_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_users_credentials (id, username, password) FROM stdin;
\.
COPY public.geo_users_credentials (id, username, password) FROM '$$PATH$$/4806.dat';

--
-- Data for Name: geo_users_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_users_location (id, nickname, latitude, longitude, "time") FROM stdin;
\.
COPY public.geo_users_location (id, nickname, latitude, longitude, "time") FROM '$$PATH$$/4810.dat';

--
-- Data for Name: geo_users_to_hobbies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_users_to_hobbies (id, hobby_name, username) FROM stdin;
\.
COPY public.geo_users_to_hobbies (id, hobby_name, username) FROM '$$PATH$$/4836.dat';

--
-- Data for Name: geo_users_to_parties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_users_to_parties (id, party_id, username) FROM stdin;
\.
COPY public.geo_users_to_parties (id, party_id, username) FROM '$$PATH$$/4839.dat';

--
-- Data for Name: geo_users_to_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.geo_users_to_roles (id, user_id, role_id) FROM stdin;
\.
COPY public.geo_users_to_roles (id, user_id, role_id) FROM '$$PATH$$/4828.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/4553.dat';

--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.
COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM '$$PATH$$/4557.dat';

--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.
COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM '$$PATH$$/4558.dat';

--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.
COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM '$$PATH$$/4559.dat';

--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.
COPY tiger.pagc_rules (id, rule, is_custom) FROM '$$PATH$$/4560.dat';

--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.
COPY topology.topology (id, name, srid, "precision", hasz) FROM '$$PATH$$/4555.dat';

--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.
COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM '$$PATH$$/4556.dat';

--
-- Name: geo_cities_to_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_cities_to_location_id_seq', 1, true);


--
-- Name: geo_close_friends_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_close_friends_id_seq', 1, false);


--
-- Name: geo_friend_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_friend_requests_id_seq', 1, false);


--
-- Name: geo_friends_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_friends_id_seq', 1, false);


--
-- Name: geo_hobbies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_hobbies_id_seq', 1, false);


--
-- Name: geo_parties_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_parties_category_id_seq', 1, false);


--
-- Name: geo_parties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_parties_id_seq', 1, false);


--
-- Name: geo_party_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_party_roles_id_seq', 1, false);


--
-- Name: geo_party_roles_party_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_party_roles_party_id_seq', 1, false);


--
-- Name: geo_party_roles_to_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_party_roles_to_users_id_seq', 1, false);


--
-- Name: geo_party_roles_to_users_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_party_roles_to_users_role_id_seq', 1, false);


--
-- Name: geo_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_roles_id_seq', 1, false);


--
-- Name: geo_users_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_users_credentials_id_seq', 1, false);


--
-- Name: geo_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_users_id_seq', 1, true);


--
-- Name: geo_users_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_users_location_id_seq', 1, false);


--
-- Name: geo_users_to_hobbies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_users_to_hobbies_id_seq', 1, false);


--
-- Name: geo_users_to_parties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_users_to_parties_id_seq', 1, false);


--
-- Name: geo_users_to_parties_party_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_users_to_parties_party_id_seq', 1, false);


--
-- Name: geo_users_to_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_users_to_roles_id_seq', 1, false);


--
-- Name: geo_users_to_roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_users_to_roles_role_id_seq', 1, false);


--
-- Name: geo_users_to_roles_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.geo_users_to_roles_user_id_seq', 1, false);


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: postgres
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: geo_cities_to_location geo_cities_to_location_city_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_cities_to_location
    ADD CONSTRAINT geo_cities_to_location_city_key UNIQUE (city);


--
-- Name: geo_cities_to_location geo_cities_to_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_cities_to_location
    ADD CONSTRAINT geo_cities_to_location_pkey PRIMARY KEY (id);


--
-- Name: geo_close_friends geo_close_friends_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_close_friends
    ADD CONSTRAINT geo_close_friends_pkey PRIMARY KEY (id);


--
-- Name: geo_friend_requests geo_friend_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_friend_requests
    ADD CONSTRAINT geo_friend_requests_pkey PRIMARY KEY (id);


--
-- Name: geo_friends geo_friends_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_friends
    ADD CONSTRAINT geo_friends_pkey PRIMARY KEY (id);


--
-- Name: geo_hobbies geo_hobbies_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_hobbies
    ADD CONSTRAINT geo_hobbies_name_key UNIQUE (name);


--
-- Name: geo_hobbies geo_hobbies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_hobbies
    ADD CONSTRAINT geo_hobbies_pkey PRIMARY KEY (id);


--
-- Name: geo_parties_category geo_parties_category_category_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_parties_category
    ADD CONSTRAINT geo_parties_category_category_key UNIQUE (category);


--
-- Name: geo_parties_category geo_parties_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_parties_category
    ADD CONSTRAINT geo_parties_category_pkey PRIMARY KEY (id);


--
-- Name: geo_parties geo_parties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_parties
    ADD CONSTRAINT geo_parties_pkey PRIMARY KEY (id);


--
-- Name: geo_party_roles geo_party_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_party_roles
    ADD CONSTRAINT geo_party_roles_pkey PRIMARY KEY (id);


--
-- Name: geo_party_roles_to_users geo_party_roles_to_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_party_roles_to_users
    ADD CONSTRAINT geo_party_roles_to_users_pkey PRIMARY KEY (id);


--
-- Name: geo_roles geo_roles_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_roles
    ADD CONSTRAINT geo_roles_name_key UNIQUE (name);


--
-- Name: geo_roles geo_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_roles
    ADD CONSTRAINT geo_roles_pkey PRIMARY KEY (id);


--
-- Name: geo_users_credentials geo_users_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_credentials
    ADD CONSTRAINT geo_users_credentials_pkey PRIMARY KEY (id);


--
-- Name: geo_users_credentials geo_users_credentials_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_credentials
    ADD CONSTRAINT geo_users_credentials_username_key UNIQUE (username);


--
-- Name: geo_users_location geo_users_location_nickname_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_location
    ADD CONSTRAINT geo_users_location_nickname_key UNIQUE (nickname);


--
-- Name: geo_users_location geo_users_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_location
    ADD CONSTRAINT geo_users_location_pkey PRIMARY KEY (id);


--
-- Name: geo_users geo_users_nickname_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users
    ADD CONSTRAINT geo_users_nickname_key UNIQUE (nickname);


--
-- Name: geo_users geo_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users
    ADD CONSTRAINT geo_users_pkey PRIMARY KEY (id);


--
-- Name: geo_users_to_hobbies geo_users_to_hobbies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_to_hobbies
    ADD CONSTRAINT geo_users_to_hobbies_pkey PRIMARY KEY (id);


--
-- Name: geo_users_to_parties geo_users_to_parties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_to_parties
    ADD CONSTRAINT geo_users_to_parties_pkey PRIMARY KEY (id);


--
-- Name: geo_users_to_roles geo_users_to_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_to_roles
    ADD CONSTRAINT geo_users_to_roles_pkey PRIMARY KEY (id);


--
-- Name: geo_parties fk-category; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_parties
    ADD CONSTRAINT "fk-category" FOREIGN KEY (category) REFERENCES public.geo_parties_category(category);


--
-- Name: geo_close_friends fk-geo_close_friends-friend-nickname; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_close_friends
    ADD CONSTRAINT "fk-geo_close_friends-friend-nickname" FOREIGN KEY (friend) REFERENCES public.geo_users(nickname);


--
-- Name: geo_close_friends fk-geo_close_friends-person-nickname; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_close_friends
    ADD CONSTRAINT "fk-geo_close_friends-person-nickname" FOREIGN KEY (person) REFERENCES public.geo_users(nickname);


--
-- Name: geo_friend_requests fk-geo_friend_requests-request_from-nickname; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_friend_requests
    ADD CONSTRAINT "fk-geo_friend_requests-request_from-nickname" FOREIGN KEY (request_from) REFERENCES public.geo_users(nickname);


--
-- Name: geo_friend_requests fk-geo_friend_requests-request_to-nickname; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_friend_requests
    ADD CONSTRAINT "fk-geo_friend_requests-request_to-nickname" FOREIGN KEY (request_to) REFERENCES public.geo_users(nickname);


--
-- Name: geo_friends fk-geo_friends-friend-nickname; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_friends
    ADD CONSTRAINT "fk-geo_friends-friend-nickname" FOREIGN KEY (friend) REFERENCES public.geo_users(nickname);


--
-- Name: geo_friends fk-geo_friends-person-nickname; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_friends
    ADD CONSTRAINT "fk-geo_friends-person-nickname" FOREIGN KEY (person) REFERENCES public.geo_users(nickname);


--
-- Name: geo_parties fk-geo_parties-creator-nickname; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_parties
    ADD CONSTRAINT "fk-geo_parties-creator-nickname" FOREIGN KEY (creator) REFERENCES public.geo_users(nickname);


--
-- Name: geo_users_location fk-geo_users_location-nickname-nickname; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_location
    ADD CONSTRAINT "fk-geo_users_location-nickname-nickname" FOREIGN KEY (nickname) REFERENCES public.geo_users(nickname);


--
-- Name: geo_users_to_roles fk-geo_users_to_roles-role_id-id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_to_roles
    ADD CONSTRAINT "fk-geo_users_to_roles-role_id-id" FOREIGN KEY (role_id) REFERENCES public.geo_roles(id);


--
-- Name: geo_users_to_roles fk-geo_users_to_roles-user_id-id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_to_roles
    ADD CONSTRAINT "fk-geo_users_to_roles-user_id-id" FOREIGN KEY (user_id) REFERENCES public.geo_users(id);


--
-- Name: geo_party_roles geo_party_roles-party_id-id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_party_roles
    ADD CONSTRAINT "geo_party_roles-party_id-id" FOREIGN KEY (party_id) REFERENCES public.geo_parties(id);


--
-- Name: geo_party_roles_to_users geo_party_roles_to_users-role_id-id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_party_roles_to_users
    ADD CONSTRAINT "geo_party_roles_to_users-role_id-id" FOREIGN KEY (role_id) REFERENCES public.geo_party_roles(id);


--
-- Name: geo_party_roles_to_users geo_party_roles_to_users-username-nickname; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_party_roles_to_users
    ADD CONSTRAINT "geo_party_roles_to_users-username-nickname" FOREIGN KEY (username) REFERENCES public.geo_users(nickname);


--
-- Name: geo_users_to_hobbies geo_users_to_hobbies-hobby_name-name; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_to_hobbies
    ADD CONSTRAINT "geo_users_to_hobbies-hobby_name-name" FOREIGN KEY (hobby_name) REFERENCES public.geo_hobbies(name);


--
-- Name: geo_users_to_hobbies geo_users_to_hobbies-username-nickname; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_to_hobbies
    ADD CONSTRAINT "geo_users_to_hobbies-username-nickname" FOREIGN KEY (username) REFERENCES public.geo_users(nickname);


--
-- Name: geo_users_to_parties geo_users_to_parties-party_id-id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_to_parties
    ADD CONSTRAINT "geo_users_to_parties-party_id-id" FOREIGN KEY (party_id) REFERENCES public.geo_parties(id);


--
-- Name: geo_users_to_parties geo_users_to_parties-username-nickname; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.geo_users_to_parties
    ADD CONSTRAINT "geo_users_to_parties-username-nickname" FOREIGN KEY (username) REFERENCES public.geo_users(nickname);


--
-- PostgreSQL database dump complete
--

